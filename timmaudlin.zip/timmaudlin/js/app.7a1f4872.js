(function(t) {
    function e(e) {
        for (var o, s, n = e[0], r = e[1], l = e[2], p = 0, h = []; p < n.length; p++) s = n[p], Object.prototype.hasOwnProperty.call(a, s) && a[s] && h.push(a[s][0]), a[s] = 0;
        for (o in r) Object.prototype.hasOwnProperty.call(r, o) && (t[o] = r[o]);
        d && d(e);
        while (h.length) h.shift()();
        return c.push.apply(c, l || []), i()
    }

    function i() {
        for (var t, e = 0; e < c.length; e++) {
            for (var i = c[e], o = !0, n = 1; n < i.length; n++) {
                var r = i[n];
                0 !== a[r] && (o = !1)
            }
            o && (c.splice(e--, 1), t = s(s.s = i[0]))
        }
        return t
    }
    var o = {},
        a = {
            app: 0
        },
        c = [];

    function s(e) {
        if (o[e]) return o[e].exports;
        var i = o[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(i.exports, i, i.exports, s), i.l = !0, i.exports
    }
    s.m = t, s.c = o, s.d = function(t, e, i) {
        s.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: i
        })
    }, s.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, s.t = function(t, e) {
        if (1 & e && (t = s(t)), 8 & e) return t;
        if (4 & e && "object" === typeof t && t && t.__esModule) return t;
        var i = Object.create(null);
        if (s.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) s.d(i, o, function(e) {
                return t[e]
            }.bind(null, o));
        return i
    }, s.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        } : function() {
            return t
        };
        return s.d(e, "a", e), e
    }, s.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, s.p = "";
    var n = window["webpackJsonp"] = window["webpackJsonp"] || [],
        r = n.push.bind(n);
    n.push = e, n = n.slice();
    for (var l = 0; l < n.length; l++) e(n[l]);
    var d = r;
    c.push([0, "chunk-vendors"]), i()
})({
    0: function(t, e, i) {
        t.exports = i("56d7")
    },
    "10ad": function(t, e, i) {
        "use strict";
        i("7821")
    },
    1764: function(t, e, i) {
        t.exports = i.p + "img/Philosophy-of-Physics-02-cropped.d0014bef.jpg"
    },
    1975: function(t, e, i) {
        t.exports = i.p + "img/Philosophy-of-Physics-01-cropped.7a2025f3.jpg"
    },
    "1aab": function(t, e, i) {
        "use strict";
        i("5e5f")
    },
    "25f8": function(t, e, i) {
        t.exports = i.p + "img/physics.e4ea37c8.jpg"
    },
    "286d": function(t, e, i) {},
    3076: function(t, e, i) {
        t.exports = i.p + "img/logic.eb7a9984.jpg"
    },
    "3b43": function(t, e, i) {
        "use strict";
        i("a595")
    },
    "443f": function(t, e, i) {
        t.exports = i.p + "img/thinker.878dc855.jpg"
    },
    "506c": function(t, e, i) {},
    "56d7": function(t, e, i) {
        "use strict";
        i.r(e);
        i("e260"), i("e6cf"), i("cca6"), i("a79d");
        var o = i("7a23");

        function a(t, e, i, a, c, s) {
            var n = Object(o["i"])("Home"),
                r = Object(o["i"])("AboutTim"),
                l = Object(o["i"])("PublicationsI"),
                d = Object(o["i"])("PublicationsII"),
                p = Object(o["i"])("Media"),
                h = Object(o["i"])("Contact");
            return Object(o["g"])(), Object(o["c"])(o["a"], null, [Object(o["f"])(n), Object(o["f"])(r), Object(o["f"])(l), Object(o["f"])(d), Object(o["f"])(p), Object(o["f"])(h)], 64)
        }
        var c = {
                class: "home"
            },
            s = Object(o["d"])('<nav class="z-depth-2 transparent "><div class="nav-wrapper"><a href="#" class="brand-logo"></a><a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a><ul class="hide-on-med-and-down center-align"><li><a href="#home-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Home">I.</a></li><li><a href="#about-tim-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="About Tim">II.</a></li><li><a href="#publications-I-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Publications I">III.</a></li><li><a href="#publications-II-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Publications II">IV.</a></li><li><a href="#media-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Media">V.</a></li><li><a href="#contact-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Contact">VI.</a></li></ul></div></nav><ul class="sidenav" id="mobile-demo"><li><a href="#home-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Home">Home</a></li><li><a href="#about-tim-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="About Tim">About Tim</a></li><li><a href="#publications-I-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Publications I">Publications I</a></li><li><a href="#publications-II-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Publications II">Publications II</a></li><li><a href="#media-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Media">Media</a></li><li><a href="#contact-link" class="smoothScrollLink tooltipped" data-position="right" data-tooltip="Contact">Contact</a></li></ul><header id="home-link" class="row width-100 height-100"><div class="col s12 l4 offset-l1 leftPanel "><div class="card transparent"><div class="card-title"><h1 class="title">Tim Maudlin</h1></div><div class="card-content white-text"><p class="nanum editable">Founder and Director</p><p class="nanum italic grey-text text-lighten-1">John Bell Institute for the Foundations of Physics</p><span class="border-accent"></span></div><div class="card-content white-text"><p class="nanum">Professor of Philosophy</p><p class="nanum italic grey-text text-lighten-1">New York University</p><span class="border-accent"></span></div></div></div><div class="col l7 rightPanel"><div class="rightPanel-content"></div></div></header>', 3);

        function n(t, e, i, a, n, r) {
            return Object(o["g"])(), Object(o["c"])("div", c, [s])
        }
        var r = {
            name: "Home",
            data: function() {
                return {}
            }
        };
        i("e69a");
        r.render = n;
        var l = r,
            d = i("707c"),
            p = i.n(d),
            h = i("443f"),
            u = i.n(h),
            b = i("25f8"),
            f = i.n(b),
            m = i("3076"),
            g = i.n(m),
            y = {
                id: "about-tim-link",
                class: "about-tim row width-100 height-100"
            },
            v = Object(o["d"])('<div class="col s12 m6 l4 offset-l1 leftPanel "><div class="leftPanel-content height-100vh"><div class="card transparent"><div class="card-title"><h1 class="title">About Tim</h1></div><div class="card-content white-text"><p class="nanum">Professor of Philosophy</p><p class="nanum italic grey-text text-lighten-1">New York University</p><span class="border-accent-secondary "></span></div></div></div></div>', 1),
            j = {
                class: "col s12 m6 l7 rightPanel"
            },
            O = {
                class: "rightPanel-content  row min-height-110vh"
            },
            w = {
                class: "col s12 l7 offset-l2 "
            },
            P = {
                class: "card z-depth-2 hoverable"
            },
            k = Object(o["f"])("div", {
                class: "card-image"
            }, [Object(o["f"])("img", {
                src: p.a,
                alt: "Professor Tim Maudlin",
                class: "materialboxed",
                "data-caption": "Professor Maudlin"
            }), Object(o["f"])("a", {
                class: "btn-floating halfway-fab waves-effect waves-light red lighten-1 pulse activator"
            }, [Object(o["f"])("i", {
                class: "material-icons tooltipped",
                "data-position": "right",
                "data-tooltip": "Additional Information"
            }, "add")])], -1),
            I = {
                class: "card-content"
            },
            T = {
                class: "standardText profileDescription"
            },
            x = Object(o["f"])("div", {
                class: "card-reveal red lighten-2"
            }, [Object(o["f"])("span", {
                class: "card-title grey-text text-darken-4"
            }, [Object(o["e"])("Additional Information"), Object(o["f"])("i", {
                class: "material-icons right"
            }, "close")]), Object(o["f"])("div", {
                class: "additionalInfo"
            }, [Object(o["f"])("h2", null, "Education"), Object(o["f"])("ul", null, [Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "school"), Object(o["e"])("Ph.D. Pittsburgh, History and Philosophy of Science")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "school"), Object(o["e"])("B.A. Yale, Physics and Philosophy")])]), Object(o["f"])("h2", null, "Memberships"), Object(o["f"])("ul", null, [Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "turned_in_not"), Object(o["f"])("a", {
                href: "https://www.johnbellinstitute.org/",
                target: "blank"
            }, "John Bell Institute for the Foundations of Physics "), Object(o["f"])("span", {
                class: "italic"
            }, "(Founder and Director)")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "turned_in_not"), Object(o["f"])("a", {
                href: "https://www.amacad.org/person/tim-we-maudlin",
                target: "blank"
            }, "American Academy of Arts and Sciences")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "turned_in_not"), Object(o["e"])("The Academie Internationale de Philosophie des Sciences")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "turned_in_not"), Object(o["e"])("Foundational Questions Institute (FQXi)")])]), Object(o["f"])("h2", null, "Awards"), Object(o["f"])("ul", null, [Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "class"), Object(o["e"])("Fellow of the American Council of Learned Societies, 2015")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "class"), Object(o["e"])("American Academy of Arts and Sciences, 2015")]), Object(o["f"])("li", null, [Object(o["f"])("i", {
                class: "material-icons left"
            }, "class"), Object(o["f"])("a", {
                href: "https://www.gf.org/fellows/all-fellows/tim-maudlin/",
                target: "blank"
            }, "Guggenheim Fellow, 2008")])])]), Object(o["f"])("div", {
                class: "chip hoverable"
            }, [Object(o["f"])("img", {
                src: u.a,
                alt: "The Thinker, Philosophy"
            }), Object(o["e"])(" Philosophy ")]), Object(o["f"])("div", {
                class: "chip hoverable"
            }, [Object(o["f"])("img", {
                src: f.a,
                alt: "Physics, the Cosmos"
            }), Object(o["e"])(" Foundations of Physics ")]), Object(o["f"])("div", {
                class: "chip hoverable"
            }, [Object(o["f"])("img", {
                src: g.a,
                alt: "Logic, Rubik's cube"
            }), Object(o["e"])(" Logic ")])], -1);

        function M(t, e, i, a, c, s) {
            return Object(o["g"])(), Object(o["c"])("section", y, [v, Object(o["f"])("div", j, [Object(o["f"])("div", O, [Object(o["f"])("div", w, [Object(o["f"])("div", P, [k, Object(o["f"])("div", I, [Object(o["f"])("p", T, Object(o["j"])(c.profileDescription), 1)]), x])])])])])
        }
        var A = {
            name: "AboutTim",
            data: function() {
                return {
                    profileDescription: "Tim Maudlin has interests primarily focused in the foundations of physics, metaphysics, and logic. His books include Quantum Non-Locality and Relativity (Blackwell, 3rd edition now available), Truth and Paradox (Oxford), The Metaphysics Within Physics (Oxford)and two volumes of 'Philosophy of Physics'. He is a member of the Academie Internationale de Philosophie des Sciences and the Foundational Questions Institute (FQXi). He has been a Guggenheim Fellow. He taught at Rutgers from 1986 to 2011, and has been a visiting professor at Harvard."
                }
            },
            mounted: function() {}
        };
        i("1aab");
        A.render = M;
        var S = A,
            L = (i("a4d3"), i("e01a"), i("9911"), {
                id: "publications-I-link",
                class: "publications row width-100 "
            }),
            _ = Object(o["d"])('<div class="col s12 m6 l4 offset-l1 leftPanel"><div class="leftPanel-content height-100vh"><div class="card transparent"><div class="card-title"><h1 class="title center-align">Publications I</h1></div><div class="card-content white-text"><p class="nanum">Published Books</p><span class="border-accent-secondary "></span></div></div></div></div>', 1),
            F = {
                class: "col s12 m6 l7 rightPanel"
            },
            B = {
                class: "rightPanel-content min-height-110vh row"
            },
            C = {
                class: "col l8 offset-l2 hide-overflow-y hide-overflow-x "
            },
            H = {
                class: "card-image"
            },
            V = Object(o["f"])("a", {
                class: "btn-floating halfway-fab waves-effect waves-light red lighten-1 pulse activator tooltipped",
                "data-position": "top",
                "data-tooltip": "About the Book"
            }, [Object(o["f"])("i", {
                class: "material-icons"
            }, "more_horiz ")], -1),
            q = {
                class: "card-content"
            },
            z = {
                class: "card-title"
            },
            R = {
                class: "card-reveal tertiary-bg"
            },
            N = Object(o["f"])("span", {
                class: "card-title grey-text text-darken-4"
            }, [Object(o["e"])("About the Book"), Object(o["f"])("i", {
                class: "material-icons right"
            }, "close")], -1),
            D = Object(o["f"])("span", {
                class: "border-accent-black"
            }, null, -1),
            W = {
                class: "description"
            },
            Q = Object(o["e"])(" Buy "),
            U = Object(o["f"])("i", {
                class: "material-icons white-text right"
            }, "shop", -1),
            G = {
                class: "tabs"
            };

        function E(t, e, i, a, c, s) {
            return Object(o["g"])(), Object(o["c"])("section", L, [_, Object(o["f"])("div", F, [Object(o["f"])("div", B, [Object(o["f"])("div", C, [(Object(o["g"])(!0), Object(o["c"])(o["a"], null, Object(o["h"])(c.publications.books, (function(t, e) {
                return Object(o["g"])(), Object(o["c"])("div", {
                    key: e,
                    id: t.swipeId,
                    class: "card hoverable"
                }, [Object(o["f"])("div", H, [Object(o["f"])("img", {
                    src: t.img,
                    alt: ""
                }, null, 8, ["src"]), V]), Object(o["f"])("div", q, [Object(o["f"])("div", z, Object(o["j"])(t.title) + " ( " + Object(o["j"])(t.year) + " )", 1), Object(o["e"])(" " + Object(o["j"])(t.publisher), 1)]), Object(o["f"])("div", R, [N, D, Object(o["f"])("p", W, Object(o["j"])(t.description), 1), Object(o["f"])("a", {
                    class: "btn secondary-bg",
                    href: t.link,
                    target: "blank"
                }, [Q, U], 8, ["href"])])], 8, ["id"])
            })), 128)), Object(o["f"])("ul", G, [(Object(o["g"])(!0), Object(o["c"])(o["a"], null, Object(o["h"])(c.publications.books, (function(t, e) {
                return Object(o["g"])(), Object(o["c"])("li", {
                    key: e,
                    class: "tab col s2"
                }, [Object(o["f"])("a", {
                    href: "#" + t.swipeId
                }, Object(o["j"])(t.year), 9, ["href"])])
            })), 128))])])])])])
        }
        var J = {
            name: "PublicationsI",
            data: function() {
                return {
                    publications: {
                        books: [{
                            img: i("1764"),
                            swipeId: "swipe-6",
                            title: "Philosophy of Physics, Volume 2: Quantum Theory",
                            description: "In this book, Tim Maudlin, one of the world’s leading philosophers of physics, offers a sophisticated, original introduction to the philosophy of quantum mechanics. The briefest, clearest, and most refined account of his influential approach to the subject, the book will be invaluable to all students of philosophy and physics.\n                                  Quantum mechanics holds a unique place in the history of physics. It has produced the most accurate predictions of any scientific theory, but, more astonishing, there has never been any agreement about what the theory implies about physical reality. Maudlin argues that the very term “quantum theory” is a misnomer. A proper physical theory should clearly describe what is there and what it does—yet standard textbooks present quantum mechanics as a predictive recipe in search of a physical theory.\n                                  In contrast, Maudlin explores three proper theories that recover the quantum predictions: the indeterministic wavefunction collapse theory of Ghirardi, Rimini, and Weber; the deterministic particle theory of deBroglie and Bohm; and the conceptually challenging Many Worlds theory of Everett. Each offers a radically different proposal for the nature of physical reality, but Maudlin shows that none of them are what they are generally taken to be.\n                                  ",
                            year: "2019",
                            publisher: "Princeton University Press",
                            link: "https://press.princeton.edu/books/hardcover/9780691183527/philosophy-of-physics"
                        }, {
                            img: i("d2be"),
                            swipeId: "swipe-5",
                            title: "New Foundations for Physical Geometry",
                            description: "Topology is the mathematical study of the most basic geometrical structure of a space. Mathematical physics uses topological spaces as the formal means for describing physical space and time. This book proposes a completely new mathematical structure for describing geometrical notions such as continuity, connectedness, boundaries of sets, and so on, in order to provide a better mathematical tool for understanding space-time. This is the initial volume in a two-volume set, the first of which develops the mathematical structure and the second of which applies it to classical and Relativistic physics.",
                            year: "2014",
                            publisher: "Oxford University Press",
                            link: "https://global.oup.com/academic/product/new-foundations-for-physical-geometry-9780198701309"
                        }, {
                            img: i("1975"),
                            swipeId: "swipe-4",
                            title: "Philosophy of Physics, Volume 1: Space and Time",
                            description: "This concise book introduces nonphysicists to the core philosophical issues surrounding the nature and structure of space and time, and is also an ideal resource for physicists interested in the conceptual foundations of space-time theory. Tim Maudlin’s broad historical overview examines Aristotelian and Newtonian accounts of space and time, and traces how Galileo’s conceptions of relativity and space-time led to Einstein’s special and general theories of relativity. Maudlin explains special relativity with enough detail to solve concrete physical problems while presenting general relativity in more qualitative terms. Additional topics include the Twins Paradox, the physical aspects of the Lorentz-FitzGerald contraction, the constancy of the speed of light, time travel, the direction of time, and more.",
                            year: "2012",
                            publisher: "Princeton University Press",
                            link: "https://press.princeton.edu/books/paperback/9780691165714/philosophy-of-physics"
                        }, {
                            img: i("dc4b"),
                            swipeId: "swipe-3",
                            title: "The Metaphysics Within Physics",
                            description: "What fundamental account of the world is implicit in physical theory? Physics straightforwardly postulates quarks and electrons, but what of the more intangible elements, such as laws of nature, universals, causation and the direction of time? Do they have a place in the physical structure of the world?\n                                  Tim Maudlin argues that the ontology derived from physics takes a form quite different from those most commonly defended by philosophers. Physics postulates irreducible fundamental laws, eschews universals, does not require a fundamental notion of causation, and makes room for the passage of time. In a series of linked essays The Metaphysics Within Physics outlines an approach to metaphysics opposed to the Humean reductionism that motivates much analytical metaphysics. \n                                  ",
                            year: "2007",
                            publisher: "Oxford University Press",
                            link: "https://global.oup.com/academic/product/the-metaphysics-within-physics-9780199575374"
                        }, {
                            img: i("f7b0"),
                            swipeId: "swipe-2",
                            title: "Truth and Paradox: Solving the Riddles",
                            description: "Consider the sentence 'This sentence is not true'. It seems that the sentence can be neither true nor not true, on pain of contradiction. Tim Maudlin sets out a novel account of logic and semantics which allows him to deal with certain notorious paradoxes which have bedevilled philosophical theories of truth. All philosophers interested in logic and language will find Truth and Paradox a stimulating read.",
                            year: "2004",
                            publisher: "Oxford University Press",
                            link: "https://global.oup.com/academic/product/truth-and-paradox-9780199203918"
                        }, {
                            img: i("b03d"),
                            swipeId: "swipe-1",
                            title: "Quantum Non-Locality and Relativity: Metaphysical Intimations of Modern Physics",
                            description: 'The third edition of Quantum Non-Locality and Relativity has been carefully updated to reflect significant developments, including a new chapter covering important recent work in the foundations of physics.\n                                  The third edition includes a premier philosophical study of Bell’s Theorem and its implication for the relativistic account of space and time as well as the "Free Will Theorem" of John Conway and Simon Kochen.\n                                  Also included is a discussion of Roderich Tumiulka’s explicit, relativistic theory that can reproduce the quantum mechanical violation of Bell’s inequality. \n                                  This book introduces philosophers to the relevant physics and demonstrates how philosophical analysis can help inform physics.\n                                ',
                            year: "1994",
                            publisher: "Oxford: Basil Blackwell",
                            link: "https://onlinelibrary.wiley.com/doi/book/10.1002/9781444396973"
                        }]
                    }
                }
            }
        };
        i("3b43");
        J.render = E;
        var X = J,
            Y = {
                id: "publications-II-link",
                class: "publicationsII row width-100 "
            },
            K = Object(o["d"])('<div class="col s12 m6 l4 offset-l1 leftPanel"><div class="leftPanel-content min-height-100vh"><div class="card transparent"><div class="card-title"><h1 class="title center-align">Publications II</h1></div><div class="card-content white-text"><p class="nanum">Published Articles &amp; More</p><span class="border-accent-secondary"></span></div></div></div></div>', 1),
            Z = {
                class: "col s12 m6 l7 rightPanel"
            },
            $ = {
                class: "rightPanel-content min-height-100vh row"
            },
            tt = {
                class: "col l8 offset-l2"
            },
            et = {
                class: "collapsible"
            },
            it = Object(o["f"])("div", {
                class: "collapsible-header"
            }, [Object(o["f"])("i", {
                class: "material-icons"
            }, "import_contacts"), Object(o["e"])("Featured Reads")], -1),
            ot = {
                class: "collapsible-body"
            },
            at = {
                class: "featuredReads"
            },
            ct = Object(o["f"])("i", {
                class: "material-icons left"
            }, "label_outline", -1),
            st = Object(o["f"])("div", {
                class: "collapsible-header"
            }, [Object(o["f"])("i", {
                class: "material-icons"
            }, "collections_bookmark"), Object(o["e"])("Articles & other Published work")], -1),
            nt = {
                class: "collapsible-body"
            },
            rt = {
                class: "articlesAndMore  "
            },
            lt = Object(o["f"])("p", {
                class: "description"
            }, "Here you can find the latest publications available: ", -1),
            dt = Object(o["f"])("i", {
                class: "material-icons left"
            }, "label_outline", -1),
            pt = Object(o["f"])("li", null, [Object(o["f"])("div", {
                class: "collapsible-header"
            }, [Object(o["f"])("i", {
                class: "material-icons"
            }, "more_horiz"), Object(o["e"])("More")]), Object(o["f"])("div", {
                class: "collapsible-body"
            }, [Object(o["f"])("span", null, "...")])], -1);

        function ht(t, e, i, a, c, s) {
            return Object(o["g"])(), Object(o["c"])("section", Y, [K, Object(o["f"])("div", Z, [Object(o["f"])("div", $, [Object(o["f"])("div", tt, [Object(o["f"])("ul", et, [Object(o["f"])("li", null, [it, Object(o["f"])("div", ot, [Object(o["f"])("ul", at, [(Object(o["g"])(!0), Object(o["c"])(o["a"], null, Object(o["h"])(c.featuredReads, (function(t, e) {
                return Object(o["g"])(), Object(o["c"])("li", {
                    key: e
                }, [Object(o["f"])("p", null, Object(o["j"])(t.source) + " : ", 1), ct, Object(o["f"])("a", {
                    href: t.link,
                    target: "blank"
                }, Object(o["j"])(t.title), 9, ["href"])])
            })), 128))])])]), Object(o["f"])("li", null, [st, Object(o["f"])("div", nt, [Object(o["f"])("ul", rt, [lt, (Object(o["g"])(!0), Object(o["c"])(o["a"], null, Object(o["h"])(c.articlesAndMore, (function(t, e) {
                return Object(o["g"])(), Object(o["c"])("li", {
                    key: e
                }, [Object(o["f"])("p", null, [dt, Object(o["f"])("a", {
                    href: t.link,
                    target: "blank"
                }, Object(o["j"])(t.source), 9, ["href"])])])
            })), 128))])])]), pt])])])])])
        }
        var ut = {
            name: "publicationsII",
            data: function() {
                return {
                    featuredReads: [{
                        source: "Scientific American",
                        title: "Philosophy Has Made Plenty of Progress",
                        link: "https://blogs.scientificamerican.com/cross-check/philosophy-has-made-plenty-of-progress/"
                    }, {
                        source: "Quanta Magazine",
                        title: "A Defense of the Reality of Time",
                        link: "https://www.quantamagazine.org/a-defense-of-the-reality-of-time-20170516/"
                    }, {
                        source: "The Atlantic",
                        title: "What Happened Before the Big Bang?",
                        link: "https://www.theatlantic.com/technology/archive/2012/01/what-happened-before-the-big-bang-the-new-philosophy-of-cosmology/251608/"
                    }],
                    articlesAndMore: [{
                        source: "PhilPeople",
                        link: "https://philpeople.org/profiles/tim-maudlin"
                    }, {
                        source: "Academia.edu",
                        link: "http://nyu.academia.edu/TimMaudlin"
                    }, {
                        source: "NYU",
                        link: "https://as.nyu.edu/faculty/tim-maudlin"
                    }]
                }
            },
            mounted: function() {}
        };
        i("85f8");
        ut.render = ht;
        var bt = ut,
            ft = {
                id: "contact-link",
                class: "contact row width-100 "
            },
            mt = Object(o["d"])('<div class="col s12 m6 l4 offset-l1 leftPanel"><div class="leftPanel-content min-height-100vh"><div class="card transparent"><div class="card-title"><h1 class="title">Contact</h1></div><div class="card-content white-text"><p class="nanum">Send a Message</p><span class="border-accent-secondary "></span></div></div></div></div>', 1),
            gt = {
                class: "col s12 m6 l7 rightPanel "
            },
            yt = {
                class: "rightPanel-content min-height-100vh row"
            },
            vt = {
                class: "col s12 l8 offset-l2"
            },
            jt = {
                class: "form-container z-depth-4 hoverable"
            },
            Ot = {
                id: "contactForm"
            },
            wt = Object(o["f"])("label", null, [Object(o["e"])("Name "), Object(o["f"])("input", {
                type: "text"
            })], -1),
            Pt = Object(o["f"])("label", null, [Object(o["e"])("Email "), Object(o["f"])("input", {
                type: "email"
            })], -1),
            kt = Object(o["f"])("label", null, [Object(o["e"])("Message "), Object(o["f"])("textarea", {
                name: "message",
                rows: "10",
                cols: "30",
                "max-row": "10",
                form: "contactForm"
            })], -1),
            It = Object(o["f"])("i", {
                class: "material-icons right"
            }, "send", -1),
            Tt = Object(o["f"])("span", null, "Submit", -1),
            xt = Object(o["f"])("p", {
                id: "credit"
            }, [Object(o["e"])(" Tim Maudlin 2020 || Website Design and Development by "), Object(o["f"])("a", {
                href: "mailto:bobbyv231@gmail.com"
            }, "Bobby Valenzuela")], -1);

        function Mt(t, e, i, a, c, s) {
            return Object(o["g"])(), Object(o["c"])(o["a"], null, [Object(o["f"])("section", ft, [mt, Object(o["f"])("div", gt, [Object(o["f"])("div", yt, [Object(o["f"])("div", vt, [Object(o["f"])("div", jt, [Object(o["f"])("form", Ot, [wt, Pt, kt, Object(o["f"])("label", null, [Object(o["f"])("a", {
                class: "btn ",
                type: "text",
                onClick: e[1] || (e[1] = function() {
                    return t.submit.apply(t, arguments)
                })
            }, [It, Tt])])])])])])])]), xt], 64)
        }
        var At = {
            name: "Contact",
            data: function() {
                return {}
            }
        };
        i("10ad");
        At.render = Mt;
        var St = At,
            Lt = {
                id: "media-link",
                class: "media row width-100 height-100"
            },
            _t = Object(o["d"])('<div class="col s12 m6 l4 offset-l1 leftPanel height-100"><div class="leftPanel-content min-height-100vh"><div class="card transparent"><div class="card-title"><h1 class="title">Media</h1></div><div class="card-content white-text"><p class="nanum animate__animated animate__pulse">Talks, Lectures, and Interviews</p><span class="border-accent-secondary"></span></div></div></div></div>', 1),
            Ft = {
                class: "col m6 l7 rightPanel "
            },
            Bt = {
                class: "rightPanel-content min-height-100vh media-content row"
            },
            Ct = {
                class: "col s10 offset-s1 "
            },
            Ht = {
                class: "video-container z-depth-3 hoverable"
            },
            Vt = {
                class: "moreVids"
            };

        function qt(t, e, i, a, c, s) {
            return Object(o["g"])(), Object(o["c"])("section", Lt, [_t, Object(o["f"])("div", Ft, [Object(o["f"])("div", Bt, [Object(o["f"])("div", Ct, [Object(o["f"])("div", Ht, [Object(o["f"])("iframe", {
                width: "560",
                height: "315",
                src: c.currentVid,
                frameborder: "0",
                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                allowfullscreen: ""
            }, null, 8, ["src"])]), Object(o["f"])("div", Vt, [(Object(o["g"])(!0), Object(o["c"])(o["a"], null, Object(o["h"])(c.vidLinks, (function(t, e) {
                return Object(o["g"])(), Object(o["c"])("div", {
                    key: e,
                    class: "mainVid video-container z-depth-3 z-depth-2 "
                }, [Object(o["f"])("a", {
                    class: "changeVid",
                    onClick: function(e) {
                        return s.updateCurrentVid(t)
                    }
                }, null, 8, ["onClick"]), Object(o["f"])("iframe", {
                    width: "560",
                    height: "315",
                    src: t,
                    frameborder: "0",
                    allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                    allowfullscreen: ""
                }, null, 8, ["src"])])
            })), 128))])])])])])
        }
        var zt = {
            name: "Media",
            data: function() {
                return {
                    currentVid: "https://www.youtube.com/embed/KXriGVf00mk",
                    vidLinks: ["https://www.youtube.com/embed/hC3ckLqsL5M", "https://www.youtube.com/embed/-TXVhxm5oAU", "https://www.youtube.com/embed/JS75WK4cHz8", "https://www.youtube.com/embed/G11L_WFLwIM"]
                }
            },
            methods: {
                updateCurrentVid: function(t) {
                    this.currentVid = t
                }
            }
        };
        i("ba3d");
        zt.render = qt;
        var Rt = zt,
            Nt = i("1157"),
            Dt = i.n(Nt),
            Wt = i("cffa"),
            Qt = i("1dac"),
            Ut = {
                name: "app",
                data: function() {
                    return {}
                },
                components: {
                    Home: l,
                    AboutTim: S,
                    PublicationsI: X,
                    PublicationsII: bt,
                    Contact: St,
                    Media: Rt
                },
                mounted: function() {
                    Dt()(document).ready((function() {
                        Dt()(".smoothScrollLink").on("click", (function(t) {
                            if ("" !== this.hash) {
                                t.preventDefault();
                                var e = this.hash;
                                Dt()("html, body").animate({
                                    scrollTop: Dt()(e).offset().top
                                }, 1300, (function() {
                                    window.location.hash = e
                                }))
                            }
                        }))
                    })), Dt()(document).ready((function() {
                        window.innerWidth >= 601 && (Wt["a"].registerPlugin(Qt["a"]), Wt["a"].to("header .leftPanel", {
                            scrollTrigger: {
                                scrub: !0,
                                trigger: ".home",
                                start: "top top",
                                end: "bottom top"
                            },
                            opacity: 0,
                            y: 700,
                            duration: 1
                        }), Wt["a"].to("header .rightPanel-content", {
                            scrollTrigger: {
                                trigger: "header .rightPanel",
                                scrub: !0,
                                start: "bottom bottom",
                                end: "bottom top",
                                markers: !1
                            },
                            opacity: 0,
                            y: 500,
                            duration: 1
                        }), Wt["a"].from(".about-tim .leftPanel", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0,
                            scale: .8,
                            yPercent: -500,
                            duration: 3
                        }), Wt["a"].from(".about-tim .rightPanel", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top bottom",
                                end: "top 5%",
                                markers: !1
                            },
                            backgroundColor: "#eeeeee",
                            yPercent: -700,
                            duration: 3
                        }), Wt["a"].from(".about-tim .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top center",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0,
                            duration: 1
                        }), Wt["a"].from(".about-tim .rightPanel-content .btn-floating", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top 90%",
                                end: "bottom bottom",
                                markers: !1
                            },
                            opacity: 0,
                            xPercent: -300,
                            duration: 1
                        }), Wt["a"].to(".about-tim .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "bottom bottom",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 100,
                            duration: 5
                        }), Wt["a"].to(".about-tim .leftPanel .card", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top top",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 200,
                            duration: 1
                        }), Wt["a"].from(".about-tim .profileDescription", {
                            scrollTrigger: {
                                trigger: ".about-tim",
                                scrub: !0,
                                start: "top bottom",
                                end: "bottom bottom",
                                markers: !1
                            },
                            yPercent: 200,
                            scale: 2.7
                        }), Wt["a"].from(".publications .leftPanel .card", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            yPercent: -1e3,
                            duration: 2
                        }), Wt["a"].from(".publications .rightPanel-content .card", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top 30%",
                                markers: !1
                            },
                            opacity: 0,
                            yPercent: 200,
                            xPercent: 500,
                            duration: 5
                        }), Wt["a"].from(".publications .tabs", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: .5,
                            xPercent: 500
                        }), Wt["a"].from(".publications .card-content", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: .5,
                            yPercent: -1500
                        }), Wt["a"].from(".publications .rightPanel", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "bottom bottom",
                                markers: !1
                            },
                            opacity: 0,
                            backgroundPosition: "-100vw 0",
                            duration: 1
                        }), Wt["a"].from(".publications .card-image", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0,
                            yPercent: -600,
                            scale: 3
                        }), Wt["a"].from(".publications .rightPanel-content .btn-floating", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0,
                            xPercent: -1e3,
                            duration: 1
                        }), Wt["a"].to(".publications .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "bottom bottom",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 100,
                            scale: .8
                        }), Wt["a"].to(".publications .leftPanel", {
                            scrollTrigger: {
                                trigger: ".publications",
                                scrub: !0,
                                start: "top top",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 100
                        }), Wt["a"].registerPlugin(Qt["a"]), Wt["a"].from(".publicationsII .rightPanel", {
                            scrollTrigger: {
                                trigger: ".publicationsII ",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0,
                            backgroundPosition: "30% -210vh",
                            scale: .8
                        }), Wt["a"].from(".publicationsII .leftPanel .card", {
                            scrollTrigger: {
                                trigger: ".publicationsII",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            yPercent: -1e3,
                            duration: 2
                        }), Wt["a"].from(".publicationsII .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".publicationsII .rightPanel-content",
                                scrub: !0,
                                start: "top center",
                                end: "top top",
                                markers: !1
                            },
                            opacity: 0
                        }), Wt["a"].to(".publicationsII .leftPanel", {
                            scrollTrigger: {
                                trigger: ".publicationsII",
                                scrub: !0,
                                start: "top top",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 100
                        }), Wt["a"].to(".publicationsII .rightPanel", {
                            scrollTrigger: {
                                trigger: ".publicationsII ",
                                scrub: !0,
                                start: "bottom bottom",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: 85,
                            duration: 1500
                        }), Wt["a"].from(".media .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".media",
                                scrub: !0,
                                start: "top center",
                                end: "bottom bottom",
                                markers: !1
                            },
                            opacity: 0,
                            xPercent: -100,
                            scale: .8
                        }), Wt["a"].from(".media .leftPanel .card", {
                            scrollTrigger: {
                                trigger: ".media",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            yPercent: -1e3,
                            duration: 2
                        }), Wt["a"].to(".media .leftPanel", {
                            scrollTrigger: {
                                trigger: ".media .leftPanel",
                                scrub: !0,
                                start: "top top",
                                end: "bottom top",
                                markers: !1
                            },
                            yPercent: -100
                        }), Wt["a"].to(".media .rightPanel", {
                            scrollTrigger: {
                                trigger: ".media",
                                scrub: !0,
                                start: "bottom bottom",
                                end: "bottom top",
                                markers: !1
                            },
                            opacity: 0,
                            yPercent: 100,
                            duration: 5
                        }), Wt["a"].registerPlugin(Qt["a"]), Wt["a"].from(".contact .leftPanel .card", {
                            scrollTrigger: {
                                trigger: ".contact",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            yPercent: -1e3,
                            duration: 2
                        }), Wt["a"].from(".contact .card-content", {
                            scrollTrigger: {
                                trigger: ".contact",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            opacity: .5,
                            yPercent: -1500
                        }), Wt["a"].from(".contact .rightPanel", {
                            scrollTrigger: {
                                trigger: ".contact",
                                scrub: !0,
                                start: "top bottom",
                                end: "top top",
                                markers: !1
                            },
                            backgroundPosition: "30% -210vh",
                            yPercent: -200
                        }), Wt["a"].from(".contact .rightPanel-content", {
                            scrollTrigger: {
                                trigger: ".contact",
                                scrub: !0,
                                start: "top 50%",
                                end: "bottom bottom",
                                markers: !1
                            },
                            opacity: 0
                        }))
                    }))
                }
            };
        i("9cdc");
        Ut.render = a;
        var Gt = Ut,
            Et = i("9483");
        Object(Et["a"])("".concat("", "service-worker.js"), {
            ready: function() {
                console.log("App is being served from cache by a service worker.\nFor more details, visit https://goo.gl/AFskqB")
            },
            registered: function() {
                console.log("Service worker has been registered.")
            },
            cached: function() {
                console.log("Content has been cached for offline use.")
            },
            updatefound: function() {
                console.log("New content is downloading.")
            },
            updated: function() {
                console.log("New content is available; please refresh.")
            },
            offline: function() {
                console.log("No internet connection found. App is running in offline mode.")
            },
            error: function(t) {
                console.error("Error during service worker registration:", t)
            }
        });
        var Jt = Object(o["b"])(Gt);
        Jt.mount("#app")
    },
    "5e5f": function(t, e, i) {},
    "707c": function(t, e, i) {
        t.exports = i.p + "img/profile.9ed37d43.jpg"
    },
    7821: function(t, e, i) {},
    "85f8": function(t, e, i) {
        "use strict";
        i("bae7")
    },
    "9cdc": function(t, e, i) {
        "use strict";
        i("c701")
    },
    a595: function(t, e, i) {},
    b03d: function(t, e, i) {
        t.exports = i.p + "img/quantum-cropped.e99a2d5d.jpg"
    },
    ba3d: function(t, e, i) {
        "use strict";
        i("506c")
    },
    bae7: function(t, e, i) {},
    c701: function(t, e, i) {},
    d2be: function(t, e, i) {
        t.exports = i.p + "img/New-foudations-for-physical-geometry-cropped.a43d01c2.jpg"
    },
    dc4b: function(t, e, i) {
        t.exports = i.p + "img/Metaphysics-within-physics-cropped.5c97a8c0.jpg"
    },
    e69a: function(t, e, i) {
        "use strict";
        i("286d")
    },
    f7b0: function(t, e, i) {
        t.exports = i.p + "img/truth-and-paradox-cropped.83510578.jpg"
    }
});
//# sourceMappingURL=app.7a1f4872.js.map